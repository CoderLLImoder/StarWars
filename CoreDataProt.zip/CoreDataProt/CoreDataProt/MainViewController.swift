//
//  ViewController.swift
//  CoreDataProt
//
//  Created by Илья Капёрский on 03.12.2023.
//

import UIKit

class MainViewController: UIViewController {

    private lazy var textField: UITextField = {
        let textField = UITextField()
        textField.text = "New character.."
        textField.textColor = UIColor.systemGray2
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.backgroundColor = .white
        textField.layer.shadowColor = UIColor.white.cgColor
        textField.layer.shadowOpacity = 0.4
        textField.layer.shadowRadius = 20
        textField.layer.shadowOffset = .zero
        textField.layer.shouldRasterize = true
        textField.layer.rasterizationScale = UIScreen.main.scale
        textField.layer.masksToBounds = false
        textField.layer.cornerRadius = 20
        textField.leftViewMode = .always
        textField.leftView = UIView(frame:CGRect(x:0, y:0, width:10, height:10))
        return textField
    }()
    
    private lazy var button: UIButton = {
        let button = UIButton()
        button.setTitle("Add character", for: .normal)
        button.layer.borderColor = UIColor.white.cgColor
        button.layer.borderWidth = 2.0
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.gray, for: .highlighted)
        button.layer.cornerRadius = 20
        /*button.layer.shadowColor = UIColor.white.cgColor
        button.layer.shadowOpacity = 0.5
        button.layer.shadowRadius = 20
        button.layer.shadowOffset = .zero
        button.layer.shouldRasterize = true
        button.layer.rasterizationScale = UIScreen.main.scale
        button.layer.masksToBounds = false*/
        button.addTarget(self, action: #selector(buttonPressed), for: .touchUpInside)
        return button
    }()
    
    private lazy var tableView: UITableView = {
            let tableView = UITableView(frame: .zero, style: .grouped)
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
            tableView.dataSource = self
            tableView.delegate = self
            tableView.translatesAutoresizingMaskIntoConstraints = false
            return tableView
        }()
    
    var presenter: MainViewPresenterProtocol!
    var users = CoreDataManager.instance.getUsers()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupHierarchy()
        setupLayout()
        let nav = navigationController?.navigationBar
        nav?.prefersLargeTitles = true
        nav?.barStyle = .black
        nav?.tintColor = UIColor.white
        nav?.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        title = "Users"
        view.backgroundColor = .black
        
        CoreDataManager.instance.clearUsers()
        CoreDataManager.instance.addUser(fullName: "Dart Vader", birthDay: Date.now, isMale: true, ava: "DV")
        CoreDataManager.instance.addUser(fullName: "Luke Skywalker", birthDay: Date.now, isMale: true, ava: "LS")
        CoreDataManager.instance.addUser(fullName: "Padme Amidala", birthDay: Date.now, isMale: false, ava: "PA")
    }


    private func setupLayout() {
        NSLayoutConstraint.activate([
            textField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textField.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 15),
            textField.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -15),
            textField.heightAnchor.constraint(equalToConstant: 50),
            
            button.topAnchor.constraint(equalTo: textField.bottomAnchor, constant: 20),
            button.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 15),
            button.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -15),
            button.heightAnchor.constraint(equalToConstant: 50),
            
            tableView.topAnchor.constraint(equalTo: button.bottomAnchor, constant: 30),
            tableView.leftAnchor.constraint(equalTo: view.leftAnchor),
            tableView.rightAnchor.constraint(equalTo: view.rightAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    private func setupHierarchy() {
        view.addSubview(textField)
        view.addSubview(button)
        view.addSubview(tableView)
    }
    
    @objc func buttonPressed () {
        CoreDataManager.instance.addUser(fullName: self.textField.text ?? "Noname", birthDay: Date.now, isMale: true, ava: "")
        users = CoreDataManager.instance.getUsers()
        tableView.reloadData()
    }
}

extension MainViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        users.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = DetailViewController()
        let cell = tableView.cellForRow(at: indexPath)
        print(cell?.textLabel?.text ?? "")
        detailVC.user = users[indexPath.row]
        changeViewController(detailVC)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let user = users[indexPath.row]
        return createDefaultCellbySetting(user)
    }
    
    func createDefaultCellbySetting(_ setting: User) -> UITableViewCell{
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        cell.textLabel?.text = setting.fullName
        cell.accessoryType = .disclosureIndicator
        cell.imageView?.layer.cornerRadius = 5
        cell.imageView?.clipsToBounds = true
        return cell
    }
    
    func changeViewController(_ nextVC: UIViewController) {
        navigationController?.pushViewController(nextVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let user = users[indexPath.row]
        let deleteAction = UIContextualAction(style: .destructive, title: "Удалить") {  (contextualAction, view, boolValue) in

            CoreDataManager.instance.deleteUser(user: user)
            self.users.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
        let swipeActions = UISwipeActionsConfiguration(actions: [deleteAction])
        tableView.reloadData()
        return swipeActions
    }
}

