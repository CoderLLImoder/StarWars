//
//  CoreDataManager.swift
//  CoreDataProt
//
//  Created by Илья Капёрский on 16.12.2023.
//

import Foundation
import CoreData

class CoreDataManager {
    
    static let instance = CoreDataManager()
    
    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "CoreDataProt")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    lazy var context: NSManagedObjectContext = {
        persistentContainer.viewContext
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func addUser(fullName: String, birthDay: Date, isMale: Bool, ava: String) {
        let newUser = User(context: context)
        newUser.fullName = fullName
        newUser.birthDay = birthDay
        newUser.isMale = isMale
        newUser.ava = ava
        saveContext()

    }
    
    func getUsers() -> [User]{
        let fetchRequest = User.fetchRequest() as NSFetchRequest<User>
        
        var users = [User]()
        
        users = try! context.fetch(fetchRequest)
        return users
    }
    
    func updateUser(user: User, newFullName: String, newBirthDay: Date, newIsMale: Bool, newAva: String) {
        user.fullName = newFullName
        user.birthDay = newBirthDay
        user.isMale = newIsMale
        do {
           try context.save()
        }
        catch {
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
        
        /*deleteUser(user: user)
        addUser(fullName: newFullName, birthDay: newBirthDay, isMale: newIsMale, ava: newAva)*/
    }
    
    func clearUsers() {
        let fetchRequest = User.fetchRequest() as! NSFetchRequest<NSFetchRequestResult>
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try context.execute(deleteRequest)
        } catch {
            print(error)
        }
    }
    
    func deleteUser(user: User) {
        context.delete(user)
    }
}
