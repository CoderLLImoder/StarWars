//
//  MainPresenter.swift
//  CoreDataProt
//
//  Created by Илья Капёрский on 05.12.2023.
//

import Foundation

protocol MainViewProtocol: class {
    func setRow(user: User)
}

protocol MainViewPresenterProtocol: class {
    init(view: MainViewProtocol, user: User, users: UsersList)
    func showRow()
    func getRows() -> UsersList
}

class MainPresenter: MainViewPresenterProtocol
{
    let view: MainViewProtocol
    let user: User
    let users: UsersList
    
    required init(view: MainViewProtocol, user: User, users: UsersList) {
        self.view = view
        self.user = user
        self.users = users
    }
    
    func showRow() {
        self.view.setRow(user: user)
    }
    
    func getRows() -> UsersList {
        return self.users
    }
}
