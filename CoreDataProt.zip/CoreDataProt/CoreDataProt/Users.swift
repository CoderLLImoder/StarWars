//
//  Users.swift
//  CoreDataProt
//
//  Created by Илья Капёрский on 05.12.2023.
//

import Foundation

struct Character {
    let name: String
    let birth: Date
    let gender: Gender?
    let ava: String
    
    init(){
        name = ""
        birth = Date.init()
        gender = nil
        ava = ""
    }
    
    init(name: String, birth: Date, gender: Gender, ava: String){
        self.name = name
        self.birth = birth
        self.gender = gender
        self.ava = ava
    }
}

enum Gender: String {
    case Male, Female
}

final class UsersList {
    static func createModel() -> [Character]  {
        [
            Character(name: "Dart Vader", birth: Date.now, gender: .Male, ava: "DV"),
            Character(name: "Luke Skywalker", birth: Date.now, gender: .Male, ava: "LS"),
            Character(name: "Padme Amidala", birth: Date.now, gender: .Female, ava: "PA")
        ]
    }
}
